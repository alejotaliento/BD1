-- SCRIPT PARA CORRER LOS PROCEDURES

-- GENERAS LOS VEHICULOS SEGUN LOS PEDIDOS
CALL generarVehiculo(1); -- PIDE NUMERO DE PEDIDO
CALL generarVehiculo(2); -- PIDE NUMERO DE PEDIDO


select * from vehiculo;

-- LUEGO DE VER LOS VEHICULOS GENERADOS, INGRESAR PATENTE DE ALGUNO PARA INICIAR EL MONTAJE
-- Y LUEGO PROCEDER A FINALIZAR SUS ESTACIONES
CALL iniciarMontaje('PATENTE DE ALGUN VEHICULO', @resultado,@mensaje);
CALL finalizarEstacion('PATENTE DE ALGUN VEHICULO', @resultado,@mensaje);


select ev.fecha_ingreso, ev.fecha_egreso, ev.idEstacion, ev.idVehiculo, e.tarea from estacion_x_vehiculo ev
inner join estacion e on ev.idEstacion=e.idEstacion;

-- REPORTES 

CALL reporte11(1); -- PIDE NUMERO DE PEDIDO
CALL reporte12(1); -- PIDE NUMERO DE PEDIDO
CALL reporte13(1); -- PIDE LINEA DE MONTAJE 
CALL punto14(); -- CREA INDICES