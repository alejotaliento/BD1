delimiter $$

create procedure reporte11(numPedido int)
BEGIN

select v.idVehiculo, v.numeroChasis, v.fechaFinalizacion, MAX(e.orden) as NRO_ULTIMA_ESTACION from vehiculo v inner join 
estacion_x_vehiculo ev on v.idVehiculo=ev.idVehiculo inner join estacion e on 
ev.idEstacion=e.idEstacion where v.detalle_pedido_idPedido=numPedido group by v.idVehiculo;


END $$


delimiter $$

create procedure reporte12(numPedido int)
BEGIN

SET @suma:=(select sum(dp.cantidad) from pedido p inner join detalle_pedido dp on p.idPedido=dp.idPedido where p.idPedido=numPedido);

select i.idInsumo, i.descripcion, (@suma * ie.cantidad) as CantidadTotal from insumo i inner join insumo_x_estacion ie on i.idInsumo=ie.idInsumo
inner join estacion e on ie.idEstacion=e.idEstacion group by i.idInsumo;

END $$

delimiter $$

create procedure reporte13(lineaMontaje int)
BEGIN

select SEC_TO_TIME(AVG(TIME_TO_SEC(TIMEDIFF(v.fechaFinalizacion,v.fechaIngreso)))) as Promedio from vehiculo v inner join estacion_x_vehiculo ev
on v.idVehiculo=ev.idVehiculo inner join estacion e on ev.idEstacion=e.idEstacion
inner join montaje m on e.idMontaje=m.idMontaje where m.idMontaje=lineaMontaje and v.fechaIngreso IS NOT NULL 
and v.fechaFinalizacion IS NOT NULL;



END $$

DELIMITER $$

create procedure punto14()
BEGIN

CREATE UNIQUE INDEX indiceVehiculo ON vehiculo(idVehiculo, numeroChasis) USING BTREE;

CREATE FULLTEXT INDEX indiceInsumo ON insumo(descripcion);


END $$


