delimiter $$
create procedure generarVehiculo(idPedidoParametro int)
BEGIN

DECLARE finished INTEGER DEFAULT 0;
DECLARE idModeloParametro INTEGER;
DECLARE nCantidadDetalle INT; 
DECLARE idVehiculoProcedure INT;

 
DECLARE nInsertados INT;

DECLARE curDetallePedido
        CURSOR FOR
            SELECT idModelo, cantidad FROM detalle_pedido WHERE idPedido = idPedidoParametro;
                
            
  DECLARE CONTINUE HANDLER
        FOR NOT FOUND SET finished = 1;
	
        OPEN curDetallePedido;
        
-- Aca comienzo el loop recorriendo el cursor.
    getDetalle: LOOP
 
        FETCH curDetallePedido INTO idModeloParametro, nCantidadDetalle;
 
        IF finished = 1 THEN
            LEAVE getDetalle;
        END IF;
 
	SET nInsertados = 0;
 
	-- Aca loopeo para hacer N inserts.
	WHILE nInsertados < nCantidadDetalle DO
    
    SET idVehiculoProcedure = getRandom();
 
	INSERT INTO Vehiculo (idVehiculo,numeroChasis, eliminado, detalle_pedido_idPedido, detalle_pedido_idModelo)VALUES (idVehiculoProcedure,lpad(conv(floor(rand()*pow(36,6)), 10, 36), 6, 0),0,idPedidoParametro, idModeloParametro);
	
     INSERT INTO estacion_x_vehiculo (fecha_ingreso,idEstacion,idVehiculo,eliminado) values (now(),(select distinct idEstacion from estacion where tarea="ESTADO INICIAL" and idMontaje=idModeloParametro),idVehiculoProcedure,0);
 
SET nInsertados = nInsertados  +1;
 
	END WHILE;
 
    END LOOP getDetalle;
 
-- Elimino el cursor de memoria
 
    CLOSE curDetallePedido;

END $$


-- OBTIENE UN NUMERO AL AZAR DE PATENTE

delimiter $$

create function getRandom() returns int
BEGIN

declare numero int default FLOOR(RAND()*(9999-0+1)+0);
declare finished integer default 0;
declare idVehiculoParametro int;



declare c1 cursor for select idVehiculo from vehiculo;



DECLARE CONTINUE HANDLER
        FOR NOT FOUND SET finished = 1;
        

        
        OPEN c1;
        
        getNumero: LOOP
 
        FETCH c1 INTO idVehiculoParametro;
 
        IF finished = 1 THEN
            LEAVE getNumero;
        END IF;
        
        
        
        IF numero = idVehiculoParametro THEN
			set numero = FLOOR(RAND()*(9999-0+1)+0);
            ELSE
            LEAVE getNumero;
            END IF;
            
            END LOOP getNumero;
            
            CLOSE c1;
            
            return numero;



END $$