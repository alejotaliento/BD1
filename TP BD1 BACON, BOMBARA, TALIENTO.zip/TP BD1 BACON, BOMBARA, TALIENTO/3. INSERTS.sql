-- INSERT MODELO

insert into modelo (idModelo,nombre,eliminado) values (1,"Renault Clio",0);
insert into modelo (idModelo,nombre,eliminado) values (2,"Renault Sandero",0);
insert into modelo (idModelo,nombre,eliminado) values (3,"Renault Megane 3",0);
insert into modelo (idModelo,nombre,eliminado) values (4,"Renault Logan",0);

-- INSERT CONCESIONARIA

call concesionaria_alta (1,"Strianese",3011111,@resultado,@mensaje);
call concesionaria_alta (2,"Concesionaria Renault",3022222,@resultado,@mensaje);
call concesionaria_alta (3,"Autofoco",3033333,@resultado,@mensaje);

-- INSERT PEDIDOS

call pedido_alta(1,1,'2019-10-03 10:00:00',@resultado,@mensaje);
call detalle_pedido_alta(1,1,5,@resultado,@mensaje);
call detalle_pedido_alta(1,2,4,@resultado,@mensaje);

call pedido_alta(2,3,'2019-10-04 14:00:00',@resultado,@mensaje);
call detalle_pedido_alta(2,3,6,@resultado,@mensaje);
call detalle_pedido_alta(2,4,3,@resultado,@mensaje);


-- INSERT MONTAJE

insert into montaje (idMontaje, idModelo, eliminado) values (1,1,0); -- CLIO
insert into montaje (idMontaje, idModelo, eliminado) values (2,2,0); -- SANDERO
insert into montaje (idMontaje, idModelo, eliminado) values (3,3,0); -- MEGANE
insert into montaje (idMontaje, idModelo, eliminado) values (4,4,0); -- LOGAN

-- INSERT ESTACION
-- ESTACION NUMERO 0
insert into estacion (idEstacion, tarea, idMontaje, orden, eliminado) values (1,"ESTADO INICIAL",1,0,0);
insert into estacion (idEstacion, tarea, idMontaje, orden, eliminado) values (2,"ESTADO INICIAL",2,0,0);
insert into estacion (idEstacion, tarea, idMontaje, orden, eliminado) values (3,"ESTADO INICIAL",3,0,0);
insert into estacion (idEstacion, tarea, idMontaje, orden, eliminado) values (4,"ESTADO INICIAL",4,0,0);

-- ESTACION NUMERO 1

insert into estacion (idEstacion, tarea, idMontaje, orden, eliminado) values (5,"FUNDICION",1,1,0);
insert into estacion (idEstacion, tarea, idMontaje, orden, eliminado) values (6,"FUNDICION",2,1,0);
insert into estacion (idEstacion, tarea, idMontaje, orden, eliminado) values (7,"FUNDICION",3,1,0);
insert into estacion (idEstacion, tarea, idMontaje, orden, eliminado) values (8,"FUNDICION",4,1,0);

-- ESTACION NUMERO 2

insert into estacion (idEstacion, tarea, idMontaje, orden, eliminado) values (9,"PRENSAS",1,2,0);
insert into estacion (idEstacion, tarea, idMontaje, orden, eliminado) values (10,"PRENSAS",2,2,0);
insert into estacion (idEstacion, tarea, idMontaje, orden, eliminado) values (11,"PRENSAS",3,2,0);
insert into estacion (idEstacion, tarea, idMontaje, orden, eliminado) values (12,"PRENSAS",4,2,0);

-- ESTACION NUMERO 3

insert into estacion (idEstacion, tarea, idMontaje, orden, eliminado) values (13,"CARROCERIA",1,3,0);
insert into estacion (idEstacion, tarea, idMontaje, orden, eliminado) values (14,"CARROCERIA",2,3,0);
insert into estacion (idEstacion, tarea, idMontaje, orden, eliminado) values (15,"CARROCERIA",3,3,0);
insert into estacion (idEstacion, tarea, idMontaje, orden, eliminado) values (16,"CARROCERIA",4,3,0);

-- ESTACION NUMERO 4

insert into estacion (idEstacion, tarea, idMontaje, orden, eliminado) values (17,"PINTURA",1,4,0);
insert into estacion (idEstacion, tarea, idMontaje, orden, eliminado) values (18,"PINTURA",2,4,0);
insert into estacion (idEstacion, tarea, idMontaje, orden, eliminado) values (19,"PINTURA",3,4,0);
insert into estacion (idEstacion, tarea, idMontaje, orden, eliminado) values (20,"PINTURA",4,4,0);

-- ESTACION NUMERO 5

insert into estacion (idEstacion, tarea, idMontaje, orden, eliminado) values (21,"ENSAMBLE AUXILIAR",1,5,0);
insert into estacion (idEstacion, tarea, idMontaje, orden, eliminado) values (22,"ENSAMBLE AUXILIAR",2,5,0);
insert into estacion (idEstacion, tarea, idMontaje, orden, eliminado) values (23,"ENSAMBLE AUXILIAR",3,5,0);
insert into estacion (idEstacion, tarea, idMontaje, orden, eliminado) values (24,"ENSAMBLE AUXILIAR",4,5,0);

-- ESTACION NUMERO 6

insert into estacion (idEstacion, tarea, idMontaje, orden, eliminado) values (25,"MONTAJE",1,6,0);
insert into estacion (idEstacion, tarea, idMontaje, orden, eliminado) values (26,"MONTAJE",2,6,0);
insert into estacion (idEstacion, tarea, idMontaje, orden, eliminado) values (27,"MONTAJE",3,6,0);
insert into estacion (idEstacion, tarea, idMontaje, orden, eliminado) values (28,"MONTAJE",4,6,0);

-- ESTACION NUMERO 7

insert into estacion (idEstacion, tarea, idMontaje, orden, eliminado) values (29,"CONTROL CALIDAD",1,7,0);
insert into estacion (idEstacion, tarea, idMontaje, orden, eliminado) values (30,"CONTROL CALIDAD",2,7,0);
insert into estacion (idEstacion, tarea, idMontaje, orden, eliminado) values (31,"CONTROL CALIDAD",3,7,0);
insert into estacion (idEstacion, tarea, idMontaje, orden, eliminado) values (32,"CONTROL CALIDAD",4,7,0);


-- INSUMOS

call insumo_alta(1,"Metal x kg",@resultado,@mensaje); -- ESTACION 1

call insumo_alta(2,"Pletina x Unidad",@resultado,@mensaje); -- ESTACION 2

call insumo_alta(3,"Electrodos x Unidad",@resultado,@mensaje); -- ESTACION 3
call insumo_alta(4,"Discos de corte x Unidad",@resultado,@mensaje); -- ESTACION 3

call insumo_alta(5,"Pintura capa protectora x litro",@resultado,@mensaje); -- ESTACION 4
call insumo_alta(6,"Pintura color x litro",@resultado,@mensaje); -- ESTACION 4

call insumo_alta(7,"Motor x Unidad",@resultado,@mensaje); -- ESTACION 6
call insumo_alta(8,"Cubiertas x Unidad",@resultado,@mensaje); -- ESTACION 6
call insumo_alta(9,"Aceite x litro",@resultado,@mensaje); -- ESTACION 6




-- INSUMO POR ESTACION

-- 1
insert into insumo_x_estacion (idEstacion,idInsumo,cantidad,eliminado) values (5,1,30,0);
insert into insumo_x_estacion (idEstacion,idInsumo,cantidad,eliminado) values (6,1,30,0);
insert into insumo_x_estacion (idEstacion,idInsumo,cantidad,eliminado) values (7,1,30,0);
insert into insumo_x_estacion (idEstacion,idInsumo,cantidad,eliminado) values (8,1,30,0);

-- 2

insert into insumo_x_estacion (idEstacion,idInsumo,cantidad,eliminado) values (9,2,20,0);
insert into insumo_x_estacion (idEstacion,idInsumo,cantidad,eliminado) values (10,2,20,0);
insert into insumo_x_estacion (idEstacion,idInsumo,cantidad,eliminado) values (11,2,20,0);
insert into insumo_x_estacion (idEstacion,idInsumo,cantidad,eliminado) values (12,2,20,0);

-- 3

insert into insumo_x_estacion (idEstacion,idInsumo,cantidad,eliminado) values (13,3,10,0);
insert into insumo_x_estacion (idEstacion,idInsumo,cantidad,eliminado) values (14,3,10,0);
insert into insumo_x_estacion (idEstacion,idInsumo,cantidad,eliminado) values (15,3,10,0);
insert into insumo_x_estacion (idEstacion,idInsumo,cantidad,eliminado) values (16,3,10,0);

insert into insumo_x_estacion (idEstacion,idInsumo,cantidad,eliminado) values (13,4,10,0);
insert into insumo_x_estacion (idEstacion,idInsumo,cantidad,eliminado) values (14,4,10,0);
insert into insumo_x_estacion (idEstacion,idInsumo,cantidad,eliminado) values (15,4,10,0);
insert into insumo_x_estacion (idEstacion,idInsumo,cantidad,eliminado) values (16,4,10,0);

-- 4

insert into insumo_x_estacion (idEstacion,idInsumo,cantidad,eliminado) values (17,5,7,0);
insert into insumo_x_estacion (idEstacion,idInsumo,cantidad,eliminado) values (18,5,7,0);
insert into insumo_x_estacion (idEstacion,idInsumo,cantidad,eliminado) values (19,5,7,0);
insert into insumo_x_estacion (idEstacion,idInsumo,cantidad,eliminado) values (20,5,7,0);

insert into insumo_x_estacion (idEstacion,idInsumo,cantidad,eliminado) values (17,6,7,0);
insert into insumo_x_estacion (idEstacion,idInsumo,cantidad,eliminado) values (18,6,7,0);
insert into insumo_x_estacion (idEstacion,idInsumo,cantidad,eliminado) values (19,6,7,0);
insert into insumo_x_estacion (idEstacion,idInsumo,cantidad,eliminado) values (20,6,7,0);

-- 6

insert into insumo_x_estacion (idEstacion,idInsumo,cantidad,eliminado) values (25,7,1,0);
insert into insumo_x_estacion (idEstacion,idInsumo,cantidad,eliminado) values (26,7,1,0);
insert into insumo_x_estacion (idEstacion,idInsumo,cantidad,eliminado) values (27,7,1,0);
insert into insumo_x_estacion (idEstacion,idInsumo,cantidad,eliminado) values (28,7,1,0);

insert into insumo_x_estacion (idEstacion,idInsumo,cantidad,eliminado) values (25,8,4,0);
insert into insumo_x_estacion (idEstacion,idInsumo,cantidad,eliminado) values (26,8,4,0);
insert into insumo_x_estacion (idEstacion,idInsumo,cantidad,eliminado) values (27,8,4,0);
insert into insumo_x_estacion (idEstacion,idInsumo,cantidad,eliminado) values (28,8,4,0);

insert into insumo_x_estacion (idEstacion,idInsumo,cantidad,eliminado) values (25,9,1,0);
insert into insumo_x_estacion (idEstacion,idInsumo,cantidad,eliminado) values (26,9,1,0);
insert into insumo_x_estacion (idEstacion,idInsumo,cantidad,eliminado) values (27,9,1,0);
insert into insumo_x_estacion (idEstacion,idInsumo,cantidad,eliminado) values (28,9,1,0);





